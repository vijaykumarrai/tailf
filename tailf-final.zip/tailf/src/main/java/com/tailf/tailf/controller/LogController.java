package com.tailf.tailf.controller;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.tailf.tailf.file.LogReader;

@Controller
public class LogController {
	@GetMapping("/log/read")
	public String getEmployeeByID() {
		ExecutorService testExecutor = Executors.newFixedThreadPool(5);
		String filePath = "C:\\Geeks\\test.log";
		LogReader logReader = new LogReader(filePath, 1000, 10);
		testExecutor.execute(logReader);
		//logReader.stopRunning();
		return logReader.getContent();
		
	}

}
