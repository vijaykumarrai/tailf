package com.tailf.tailf.socket;

public class LogData {
	String content = "hi";

	public void setContent(String string) {
		content = string;
	}
}