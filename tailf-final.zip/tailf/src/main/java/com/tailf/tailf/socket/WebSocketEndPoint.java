package com.tailf.tailf.socket;

import java.io.IOException;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint(value = "/log/{username}")
public class WebSocketEndPoint {

	private Session session;
	private static Set<WebSocketEndPoint> webSocketEndPoints = new CopyOnWriteArraySet<>();
	private static HashMap<String, String> users = new HashMap<>();

	@OnOpen
	public void onOpen(Session session, @PathParam("username") String username) throws IOException {

		this.session = session;
		webSocketEndPoints.add(this);
		users.put(session.getId(), username);

		LogData message = new LogData();

		message.setContent("Connected!");
		try {
			broadcast(message);
		} catch (EncodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@OnMessage
	public void onMessage(Session session, LogData message) throws IOException {

				try {
			broadcast(message);
		} catch (EncodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@OnClose
	public void onClose(Session session) throws IOException {

		webSocketEndPoints.remove(this);
		LogData message = new LogData();
		message.setContent("Disconnected!");
		try {
			broadcast(message);
		} catch (EncodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@OnError
	public void onError(Session session, Throwable throwable) {
		// Do error handling here
	}

	private static void broadcast(LogData message) throws IOException, EncodeException {

		webSocketEndPoints.forEach(endpoint -> {
			synchronized (endpoint) {
				try {
					endpoint.session.getBasicRemote().sendObject(message);
				} catch (IOException | EncodeException e) {
					e.printStackTrace();
				}
			}
		});
	}
}