package com.tailf.tailf.file;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LogReader implements Runnable {
	private static final String FILE_MODE = "rw";

	private int pauseInterval;
	private File fileName;
	private int prevLines;
	private long currentIndex;
	private boolean running;
	private String content;

	public LogReader(String fileName, int pauseInterval, int prevLines) {
		this.fileName = new File(fileName);
		this.pauseInterval = pauseInterval;
		this.prevLines = prevLines;
		running = true;
	}

	public void run() {
		try {
			long fileLength = fileName.length();
			// currentIndex = fileLength - prevLines;
			while (running) {
				fileLength = fileName.length();
				if (fileLength > currentIndex) {
					// Reading and writing file
					RandomAccessFile raFile = new RandomAccessFile(fileName, FILE_MODE);
					raFile.seek(currentIndex);
					String logContent = null;
					while ((logContent = raFile.readLine()) != null) {
						System.out.println(logContent);
						content+= logContent;

						// need to call onMessage method here
					}
					currentIndex = raFile.getFilePointer();
					raFile.close();
				}
				Thread.sleep(pauseInterval);
			}
		} catch (Exception e) {
			System.out.println(e);
			stopRunning();
		}
	}

	public static void main(String argv[]) {

		System.out.println("Start");
		ExecutorService testExecutor = Executors.newFixedThreadPool(5);
		String filePath = "C:\\Geeks\\test.log";
		LogReader logReader = new LogReader(filePath, 1000, 10);
		testExecutor.execute(logReader);
	}

	public void stopRunning() {
		running = false;
	}

	public String getContent() {
		// TODO Auto-generated method stub
		return content;

	}
}